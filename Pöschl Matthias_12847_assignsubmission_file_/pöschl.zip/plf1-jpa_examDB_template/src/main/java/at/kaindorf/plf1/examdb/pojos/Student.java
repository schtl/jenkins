/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author Matthias Pöschl
 */
@Entity
@NamedQueries
({
    @NamedQuery(name = "Student.getStudentByClassnameAndSubject", query = "SELECT s FROM Student s WHERE s.classname LIKE :classname AND s.exams.subject.shortname LIKE :shortname"),
    @NamedQuery(name = "Student.countStudentFromGradeWithExamInTimePeriod", query = "SELECT s FROM Student s WHERE s.classname LIKE :grade AND s.exams.dateofexam BETWEEN :startdate AND :enddate")
})
public class Student {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long studentId;
  private String firstname;
  private String lastname;
  @OneToMany(cascade  = CascadeType.PERSIST, mappedBy = "student")
  private Collection<Exam> exams;
  @ManyToOne
  @JoinColumn(name = "classnameId")
  private Classname classname;

    public Student() {
    }

    public Student(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    public Classname getClassname() {
        return classname;
    }

    public void setClassname(Classname classname) {
        this.classname = classname;
    }

    @Override
    public String toString() {
        return String.format("%s - %s", firstname, lastname);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.studentId);
        hash = 59 * hash + Objects.hashCode(this.firstname);
        hash = 59 * hash + Objects.hashCode(this.lastname);
        hash = 59 * hash + Objects.hashCode(this.exams);
        hash = 59 * hash + Objects.hashCode(this.classname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (!Objects.equals(this.firstname, other.firstname)) {
            return false;
        }
        if (!Objects.equals(this.lastname, other.lastname)) {
            return false;
        }
        if (!Objects.equals(this.studentId, other.studentId)) {
            return false;
        }
        if (!Objects.equals(this.exams, other.exams)) {
            return false;
        }
        if (!Objects.equals(this.classname, other.classname)) {
            return false;
        }
        return true;
    }
    
    
  
    
  
}
