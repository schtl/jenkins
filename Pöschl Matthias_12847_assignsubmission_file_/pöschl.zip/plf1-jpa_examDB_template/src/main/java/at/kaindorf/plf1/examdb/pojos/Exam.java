/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.time.LocalDate;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author Matthias Pöschl
 */
@Entity
public class Exam {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long examId;
  
  private LocalDate dateofexam;
  private Integer duration;
  @ManyToOne
  @JoinColumn(name = "studentId")
  private Student student;
  @ManyToOne
  @JoinColumn(name = "subjectId")
  private Subject subject;

    public Exam() {
    }

    public Exam(LocalDate dateofexam, Integer duration) {
        this.dateofexam = dateofexam;
        this.duration = duration;
    }

    public Long getExamId() {
        return examId;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public LocalDate getDateofexam() {
        return dateofexam;
    }

    public void setDateofexam(LocalDate dateofexam) {
        this.dateofexam = dateofexam;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return String.format("%ld - %d", dateofexam, duration);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.examId);
        hash = 71 * hash + Objects.hashCode(this.dateofexam);
        hash = 71 * hash + Objects.hashCode(this.duration);
        hash = 71 * hash + Objects.hashCode(this.student);
        hash = 71 * hash + Objects.hashCode(this.subject);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Exam other = (Exam) obj;
        if (!Objects.equals(this.examId, other.examId)) {
            return false;
        }
        if (!Objects.equals(this.dateofexam, other.dateofexam)) {
            return false;
        }
        if (!Objects.equals(this.duration, other.duration)) {
            return false;
        }
        if (!Objects.equals(this.student, other.student)) {
            return false;
        }
        if (!Objects.equals(this.subject, other.subject)) {
            return false;
        }
        return true;
    }
    
    
    
    
  
  
  
}
