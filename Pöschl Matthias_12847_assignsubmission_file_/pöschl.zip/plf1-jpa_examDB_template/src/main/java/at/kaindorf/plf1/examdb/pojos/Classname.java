/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
/**
 *
 * @author Matthias Pöschl
 */
@Entity
public class Classname {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long classId;
  @Column(length = 10)
  private String classname;
  
  @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "classname")
  private Collection<Student> students;

    public Classname() {
    }

  
    public Classname(String classname) {
        this.classname = classname;
    }

    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Collection<Student> getStudents() {
        return students;
    }

    public void setStudents(Collection<Student> students) {
        this.students = students;
    }

    @Override
    public String toString() {
        return String.format("%s", classname);
    }
  
    
    
  
  
}
