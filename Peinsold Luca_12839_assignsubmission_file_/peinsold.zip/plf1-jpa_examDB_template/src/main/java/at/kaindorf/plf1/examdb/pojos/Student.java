/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author Luca Peinsold
 */
@Entity
//@NamedQueries({
//    @NamedQuery(name ="Student.getStudentsByClassnameAndSubject", query = "SELECT"),
//    @NamedQuery(name ="Student.countStudentsFromGradeWithExamInTimePeriod", query = "SELECT")
//})
public class Student {

    public Student() {
    }

    public Student(String firstname, String lastname, Collection<Exam> exams, Classname classname) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.exams = exams;
        this.classname = classname;
    }
    
    
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)  
  @Column(name = "student_id")
  private Long studentId;
  
  
  private String firstname;
  private String lastname;
  
  @OneToMany(mappedBy = "student")
  private Collection<Exam> exams;
  
  @ManyToOne(cascade = CascadeType.PERSIST)
  @JoinColumn(name="classname",nullable = false)
  private Classname classname;
  
  
  public void addExam(Exam e)
  {
      exams.add(e);
  }
  
}
