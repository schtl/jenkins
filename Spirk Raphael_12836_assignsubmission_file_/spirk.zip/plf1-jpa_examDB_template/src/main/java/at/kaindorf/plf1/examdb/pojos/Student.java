/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author Raphael Spirk
 */
@Entity
@NamedQueries({// WHERE s.classname = :classname AND s.exams.subject.shortname = :subject
    @NamedQuery(name = "Student.getStudentsByClassnameAndSubject", 
            query = "SELECT s FROM Student s INNER JOIN Exam e ON e.student.studentId = s.studentId WHERE s.classname = :classname AND e.subject.shortname = :subject"),
                // WHERE s.classname LIKE :grade AND s.exams.dateofexam >= :startDate AND s.exams.dateofexam <= :endDate
    @NamedQuery(name = "Student.countStudentsFromGradeWithExamInTimePeriod", 
            query = "SELECT COUNT(s) FROM Student s INNER JOIN Exam e ON e.student.studentId = s.studentId WHERE s.classname LIKE :grade AND e.dateofexam >= :startDate AND e.dateofexam <= :endDate")
})
public class Student {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
  private Long studentId;
@Column(length = 80)
  private String firstname;
@Column(length = 80)
  private String lastname;

@OneToMany(mappedBy = "student")
  private Collection<Exam> exams;
  
  @ManyToOne
  @JoinColumn(name = "classname", nullable = false)
  private Classname classname;

    public Student() {
    }

    public Student(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public Long getStudentId() {
        return studentId;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public Classname getClassname() {
        return classname;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    public void setClassname(Classname classname) {
        classname.addStudent(this);
        this.classname = classname;
    }
  
  public void addExam(Exam exam) {
      if(!exams.contains(exam)) {
          exams.add(exam);
      }
  }
}
