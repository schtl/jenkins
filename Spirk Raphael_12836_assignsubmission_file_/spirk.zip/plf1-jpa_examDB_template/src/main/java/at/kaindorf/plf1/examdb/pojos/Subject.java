/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author Raphael Spirk
 */
@Entity
public class Subject {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
  private Long subjectId;
@Column(length = 100)
  private String longname;
@Column(length = 10)
  private String shortname;
@Column(nullable = false)
  private boolean written;

@OneToMany(mappedBy = "subject", cascade = CascadeType.PERSIST)
  private Collection<Exam> exams;

    public Subject() {
    }

    public Subject(String longname, String shortname, boolean written) {
        this.longname = longname;
        this.shortname = shortname;
        this.written = written;
    }

    public Long getSubjectId() {
        return subjectId;
    }

    public String getLongname() {
        return longname;
    }

    public String getShortname() {
        return shortname;
    }

    public boolean isWritten() {
        return written;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }

    public void setLongname(String longname) {
        this.longname = longname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    public void setWritten(boolean written) {
        this.written = written;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }
  
    public void addExams(Exam e) {
        if(!exams.contains(e)) {
            exams.add(e);
        }
    }
}
