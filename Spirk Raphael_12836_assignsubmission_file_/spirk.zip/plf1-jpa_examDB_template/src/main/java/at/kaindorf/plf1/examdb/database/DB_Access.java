/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Raphael Spirk
 */
public final class DB_Access {
    
    private static DB_Access theInstance;
    
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("ExamDB_PU");
    private EntityManager em;

    private DB_Access() { }
    
    public static DB_Access getInstance() {
        if (theInstance == null) {
            theInstance = new DB_Access();
        }
        return theInstance;
    }

    public void connect() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    public void disconnect() {
        em.getTransaction().commit();
        em.close();
        emf.close();
    }

    /**
     * read the classnames from csv-file and persist values
     * pathname of csv-file: \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(
                new FileInputStream("/home/student/NetBeansProjects/plf1-jpa_examDB_template/src/main/resources/res/classnames.csv"), "UTF8"));
        
        String line = "";
        
        while((line = br.readLine()) != null) {
            
            Classname classname = new Classname(line);
            
            em.persist(classname);
        }
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        
        TypedQuery<Student> query = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        query.setParameter("classname", classname);
        query.setParameter("subject", subject);
        
        List<Student> students = query.getResultList();
                
        return students;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        
        Query query = em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod");
        query.setParameter("grade", grade+"%");
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        
        Long studentCount = (Long) query.getSingleResult();
        
        return studentCount;
    }

}
