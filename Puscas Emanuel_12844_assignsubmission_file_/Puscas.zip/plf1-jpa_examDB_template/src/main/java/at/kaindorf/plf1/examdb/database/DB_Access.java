/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author EmanuelPuscas
 */
public final class DB_Access {

    // ToDo: insert singleton-code here
    
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("ExamDB_PU");
    private EntityManager em = emf.createEntityManager();
    
    public static DB_Access getInstance() {
        // ToDo: insert code here
        return null;
    }
    
    public static void main(String[] args) {
        DB_Access db = new DB_Access();
        Scanner sc = new Scanner(System.in);
        char input =' ';
        
        
        do
        {
            System.out.println("1 - connect");
            System.out.println("2 - import classnames");
            System.out.println("e - disconnect");
            
            input = sc.next().charAt(0);
            
            switch(input)
            {
                case '1': db.connect(); break;
                case '2': try { db.importClassnames();} catch (Exception e) {System.out.println("Klassen wurden NICHT hinzugefügt!");};break;
            }
        } while(input!='e');
        db.disconnect();
    }

    public void connect() {
        em.getTransaction().begin();
        em.getTransaction().commit();
        System.out.println("\nConnection Established\n");
    }

    public void disconnect() {
        em.close();
        System.out.println("\nDisconnected\n");
    }

    /**
     * read the classnames from csv-file and persist values
     * pathname of csv-file: \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        // ToDo: insert code here
        String path = System.getProperty("user.dir")+File.separator+"src"+File.separator+"main"+File.separator+"resources"+File.separator+"res"+File.separator+"classnames.csv";
        File file = new File(path);
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String line = "";
        while((line = br.readLine())!=null)
        {
            Classname c = new Classname(line);
            em.persist(c);
        }
        connect();
        System.out.println("\nKlassen wurden hinzugefügt!\n");
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        // ToDo: insert code here
        List<Student> students = new ArrayList<>();
        TypedQuery<Student> tq = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        students = tq.getResultList();
        return students;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        // ToDo: insert code here
        long count = 0;
        
        TypedQuery tq = (TypedQuery)em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod", Student.class);
        tq.setParameter("year", grade);
        count = Long.parseLong(tq.getSingleResult().toString());
        return count;
    }

}
