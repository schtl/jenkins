/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Mario Schweiger
 */
public final class DB_Access {

    private static DB_Access dba;
    private EntityManagerFactory emf;
    private EntityManager em;

    // ToDo: insert singleton-code here
    public static DB_Access getInstance() {
        // ToDo: insert code here
        if (dba == null) {
            dba = new DB_Access();
        }
        return dba;
    }

    public void connect() {
        // ToDo: insert code here
        if (emf == null) {
            emf = Persistence.createEntityManagerFactory("ExamDB_PU");
        }
        if (em == null) {
            em = emf.createEntityManager();
        }
    }

    public void disconnect() {
        // ToDo: insert code here
        em.close();
        emf.close();
    }

    /**
     * read the classnames from csv-file and persist values pathname of
     * csv-file:
     * \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        // ToDo: insert code here
        File file = new File(System.getProperty("user.dir")
                + File.separator + "src"
                + File.separator + "main"
                + File.separator + "resources"
                + File.separator + "res"
                + File.separator + "classnames.csv");

        BufferedReader br = new BufferedReader(new FileReader(file));
        String input;

        while ((input = br.readLine()) != null) {
            Classname classname = new Classname(input);

            em.getTransaction().begin();
            em.persist(classname);
            em.getTransaction().commit();
        }

    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        // ToDo: insert code here
        TypedQuery query = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        query.setParameter("classname", classname);
        query.setParameter("shortname", subject);
        List<Student> students = query.getResultList();

        return students;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        // ToDo: insert code here
        TypedQuery query = em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod", Student.class);
        query.setParameter("startdate", startDate);
        query.setParameter("enddate", endDate);
        //query.setParameter("grade", grade);
        Long count = Long.parseLong(query.getSingleResult().toString());

        return count;
    }

    public static void main(String[] args) {
        try {
            dba = DB_Access.getInstance();
            dba.connect();
            dba.importClassnames();

            Scanner input = new Scanner(System.in);
            System.out.print("Enter a classname: ");
            String classname = input.nextLine();
            System.out.print("Enter a subject: ");
            String subject = input.nextLine();

            List<Student> students = new LinkedList<>();
            students = dba.getStudentsByClassnameAndSubject(classname, subject);

            for (Student student : students) {
                System.out.format("%s %s", student.getFirstname(), student.getLastname());
            }

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");

            int grade = 0;

            while (grade != 1 || grade != 2 || grade != 3 || grade != 4 || grade != 5) {
                System.out.println("Enter a grade: ");
                grade = input.nextInt();
            }

            try {
                input.nextLine();
                System.out.print("Enter start date: ");
                String startdate = input.nextLine();
                System.out.print("Enter end date: ");
                String enddate = input.nextLine();

                LocalDate startDate = LocalDate.parse(startdate, dtf);
                LocalDate endDate = LocalDate.parse(enddate, dtf);

                Long count = dba.countStudentsFromGradeWithExamInTimePeriod(startDate, endDate, grade);
                
                System.out.println("Students with exams in chosen time period: " + count);
            }
            catch(Exception ex)
            {
                System.out.println("Wrong date format.");
            }

            dba.disconnect();
        } catch (IOException ex) {
            System.out.println("CSV not found");
        }
    }

}
