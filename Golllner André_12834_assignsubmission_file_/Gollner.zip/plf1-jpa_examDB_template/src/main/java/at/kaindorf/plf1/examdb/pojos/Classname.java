/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
/**
 *
 * @author André Gollner
 */
@Entity
public class Classname {
  @Id
  @Column(name = "class_id", nullable = false)
  private Long classId;
  @Column(length = 10)
  private String classname;
  @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "classname")
  private Collection<Student> students;

    public Classname() {
    }

    public Classname(Long classId, String classname) {
        this.classId = classId;
        this.classname = classname;
        
    }

    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Collection<Student> getStudents() {
        return students;
    }

    public void setStudents(Collection<Student> students) {
        this.students = students;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.classId);
        hash = 47 * hash + Objects.hashCode(this.classname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Classname other = (Classname) obj;
        if (!Objects.equals(this.classname, other.classname)) {
            return false;
        }
        if (!Objects.equals(this.classId, other.classId)) {
            return false;
        }
        return true;
    }
  
    public void addStudent(Student student)
    {
        student.setClassname(this);
        students.add(student);
    }
}
