/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author André Gollner
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "Student.getStudentsByClassnameAndSubject", query = "SELECT DISTINCT s FROM Student s join Exam e WHERE "
            + "UPPER(s.classname.classname) LIKE UPPER(:classname) AND UPPER(e.subject.shortname) LIKE UPPER(:shortname) "
            + "ORDER BY s.lastname"),
    @NamedQuery(name = "Student.countStudentsFromGradeWithExamInTimePeriod", query = "SELECT COUNT(s) FROM Student s join Exam e"
            + " WHERE SUBSTR(s.classname.classname, 1, 2) LIKE :grade AND e.dateofexam BETWEEN :startdate AND :enddate")
})
public class Student {
  @Id
  @Column(name = "student_id", nullable = false)
  private Long studentId;
  @Column(length = 80)
  private String firstname;
  @Column(length = 80)
  private String lastname;
  @OneToMany(mappedBy = "student")
  private Collection<Exam> exams;
  @ManyToOne(optional = false)
  @JoinColumn(name = "classname", nullable = false)
  private Classname classname;

    public Student() {
    }

    public Student(Long studentId, String firstname, String lastname) {
        this.studentId = studentId;
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    public Classname getClassname() {
        return classname;
    }

    public void setClassname(Classname classname) {
        this.classname = classname;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.studentId);
        hash = 47 * hash + Objects.hashCode(this.firstname);
        hash = 47 * hash + Objects.hashCode(this.lastname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (!Objects.equals(this.firstname, other.firstname)) {
            return false;
        }
        if (!Objects.equals(this.lastname, other.lastname)) {
            return false;
        }
        if (!Objects.equals(this.studentId, other.studentId)) {
            return false;
        }
        return true;
    }
  public void addExam(Exam exam)
  {
      exam.setStudent(this);
      exams.add(exam);
  }

    @Override
    public String toString() {
        return String.format("Cat.Nr: %d Name: %s %s Class: %s", studentId, firstname, lastname, classname.getClassname());
    }
  
}
