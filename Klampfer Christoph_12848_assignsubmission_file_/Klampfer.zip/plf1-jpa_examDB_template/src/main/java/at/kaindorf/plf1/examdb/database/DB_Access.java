/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Christoph Klampfer
 */
public final class DB_Access {

    EntityManager em;
    EntityManagerFactory emf;

    // ToDo: insert singleton-code here
    private DB_Access theInstace = getInstance();
    
    public static DB_Access getInstance() {
        // ToDo: insert code here
        return null;
    }

    public void connect() {
        // ToDo: insert code here
        emf = Persistence.createEntityManagerFactory("ExamDB_PU");
        em = emf.createEntityManager();
    }

    public void disconnect() {
        // ToDo: insert code here
        em.close();
        emf.close();
    }

    /**
     * read the classnames from csv-file and persist values pathname of
     * csv-file:
     * \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        // ToDo: insert code here
        List<Classname> classnames = new LinkedList<>();
        String path = System.getProperty("user.dir") + File.separator
                + "src" + File.separator + "main" + File.separator + "ressources"
                + File.separator + "res" + File.separator + "classnames.csv";
        FileReader fr = new FileReader(path);
        BufferedReader br = new BufferedReader(fr);
        String s;
        while ((s = br.readLine()) != null) {
            Classname classname = new Classname(s);
            classnames.add(classname);
        }
        fr.close();
        br.close();
        em.persist(classnames);
        em.getTransaction().begin();
        em.getTransaction().commit();
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        // ToDo: insert code here
        Scanner scan = new Scanner(System.in);
        List<Student> students;
        TypedQuery<Student> tq = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        System.out.print("Enter a classname to search for: ");
        String classPara = scan.next();
        System.out.print("Enter the shortname of a Subject to search for: ");
        String shortname = scan.next();
        tq.setParameter("classname", classPara);
        tq.setParameter("subject", shortname);
        students = tq.getResultList();
        return students;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        // ToDo: insert code here
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        Scanner scan = new Scanner(System.in);
        long count;
        TypedQuery<Student> tq = em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod", Student.class);
        System.out.println("Date Format: dd.MM.yyyy");
        System.out.print("Enter the minimum date: ");
        String help = scan.next();
        LocalDate min = LocalDate.parse(help, dtf);
        System.out.print("Enter the maximum date: ");
        String help2 = scan.next();
        LocalDate max = LocalDate.parse(help2, dtf);
        tq.setParameter("maxDate", max);
        tq.setParameter("minDate", min);
        count = tq.getResultList().size();
        return count;
    }

}
