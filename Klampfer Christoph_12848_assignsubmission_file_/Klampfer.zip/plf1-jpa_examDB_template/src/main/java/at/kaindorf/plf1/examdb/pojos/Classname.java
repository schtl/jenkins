/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author Christoph Klampfer
 */
@Entity

public class Classname {

    @GeneratedValue(strategy = GenerationType.AUTO)

    @Id
    @Column(nullable = false)
    private Long classId;
    @Column(length = 10)
    private String classname;

    public Classname(String classname) {
        this.classname = classname;
    }

    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "ClassName")
    private Collection<Student> students;

    public void addStudents(Student student) {
        if (!students.contains(student)) {
            students.add(student);
        }
    }

    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Collection<Student> getStudents() {
        return students;
    }

    public void setStudents(Collection<Student> students) {
        this.students = students;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.classId);
        hash = 97 * hash + Objects.hashCode(this.classname);
        hash = 97 * hash + Objects.hashCode(this.students);
        hash = 97 * hash + Objects.hashCode(this.students);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Classname other = (Classname) obj;
        if (!Objects.equals(this.classname, other.classname)) {
            return false;
        }
        if (!Objects.equals(this.classId, other.classId)) {
            return false;
        }
        if (!Objects.equals(this.students, other.students)) {
            return false;
        }
        if (!Objects.equals(this.students, other.students)) {
            return false;
        }
        return true;
    }

}
