/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.*;

/**
 *
 * @author Kerstin Klaminger
 */
@Entity
@NamedQueries({
    @NamedQuery(name="Student.getStudentsByClassnameAndSubject",
            query="SELECT s FROM Student s WHERE UPPER(s.classname) LIKE UPPER(:classname) AND UPPER(s.exams.subject.shortname) LIKE UPPER(:examshort) ORDER BY s.lastname"),
    @NamedQuery(name="Student.countStudentsFromGradeWithExamInTimePeriod",query="SELECT COUNT(s.student_id) FROM Student s WHERE ")
})
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "student_id")
    private Long studentId;
    @Column(length = 80)
    private String firstname;
    @Column(length = 80)
    private String lastname;

    @OneToMany(mappedBy = "student")
    private Collection<Exam> exams;
    @JoinColumn(name = "classname", nullable = false)
    @ManyToOne(cascade = CascadeType.PERSIST)
    private Classname classname;

    public Student() {
    }

    public Student(String firstname, String lastname, Collection<Exam> exams, Classname classname) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.exams = exams;
        this.classname = classname;
    }

    public Student(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public Long getStudentId() {
        return studentId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    public void addExam(Exam exam) {
        if (exams == null) {
            exams = new ArrayList<>();
        }
        exam.setStudent(this);
        exams.add(exam);
    }

    public Classname getClassname() {
        return classname;
    }

    public void setClassname(Classname classname) {
        this.classname = classname;
    }

}
