/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author matthiasfina
 */
public final class DB_Access {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    
    private static final String path = System.getProperty("user.dir")+File.separator+"src"+File.separator+"res"+File.separator+"classnames.csv";

    
    // ToDo: insert singleton-code here
    
    public static DB_Access getInstance() {
        // ToDo: insert code here
        return null;
    }
 
    public void connect() {
        // ToDo: insert code here
        emf = Persistence.createEntityManagerFactory("ExamDB_PU");
        em = emf.createEntityManager();
    }

    public void disconnect() {
        // ToDo: insert code here
        em.close();
        emf.close();
    }

    /**
     * read the classnames from csv-file and persist values
     * pathname of csv-file: \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        // ToDo: insert code here
        List<String> classes = new ArrayList<>();
        
        BufferedReader br = new BufferedReader(new InputStreamReader(
        new FileInputStream(path),"UTF8"));
        
        String line = br.readLine();
        
        
        while((line = br.readLine())!= null)
        {
            classes.add(line);
            Student s = new Student

            
            em.persist(s);
            
            em.getTransaction().begin();
            em.getTransaction().commit();
        }
        
        br.close();
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        // ToDo: insert code here
        
        return null;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        // ToDo: insert code here
        TypedQuery<Student> query2 = em.createNamedQuery("countStudentsFromGradeWithExamInTimePeriod",Student.class);
        query2.setParameter("student_", grade);
        //int count1 = query2.getSingleResult();
        return null;
    }

}
