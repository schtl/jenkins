/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author matthiasfina
 */
@Entity
public class Subject {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
  private Long subjectId;
@Column(length = 100)
  private String longname;
@Column(length = 10)
private String shortname;
@Column(nullable = false)
  private boolean written;
@OneToMany(mappedBy = "exam")
  private Collection<Exam> exams;

    public Subject() {
    }

    public Subject(String longname, String shortname, boolean written) {
        this.longname = longname;
        this.shortname = shortname;
        this.written = written;
    }

    public void addExam(Exam exam)
    {
        if(!exams.contains(exam))
        {
            exams.add(exam);
        }
    }
    public String getLongname() {
        return longname;
    }

    public void setLongname(String longname) {
        this.longname = longname;
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    public boolean isWritten() {
        return written;
    }

    public void setWritten(boolean written) {
        this.written = written;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.longname);
        hash = 23 * hash + Objects.hashCode(this.shortname);
        hash = 23 * hash + (this.written ? 1 : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Subject other = (Subject) obj;
        if (this.written != other.written) {
            return false;
        }
        if (!Objects.equals(this.longname, other.longname)) {
            return false;
        }
        if (!Objects.equals(this.shortname, other.shortname)) {
            return false;
        }
        return true;
    }

    
    @Override
    public String toString() {
        return "Subject{" + "subjectId=" + subjectId + ", longname=" + longname + ", shortname=" + shortname + ", written=" + written + ", exams=" + exams + '}';
    }
  

}
