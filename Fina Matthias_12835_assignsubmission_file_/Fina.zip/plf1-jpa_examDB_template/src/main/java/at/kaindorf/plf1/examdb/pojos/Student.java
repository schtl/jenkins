/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 *
 * @author matthiasfina
 */
@Entity
@NamedQueries({
@NamedQuery(name="Student.getStudentsByClassnameAndSubject",
        query="SELECT s FROM Student s WHERE s.classname.students.exams LIKE : s. ORDER BY s.lastname ASC"),
@NamedQuery(name="Student.countStudentsFromGradeWithExamInTimePeriod",query="")
})
public class Student {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
  private Long studentId;
@Column(length = 80)
  private String firstname;
@Column(length = 80)
  private String lastname;
@Column(nullable = false)
  private Classname classname;
@ManyToOne(cascade = CascadeType.PERSIST)
@JoinColumn(name = "students")
private Collection<Exam> exams;

    public Student() {
    }

    public Student(String firstname, String lastname, Classname classname) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.classname = classname;
    }

    public void addExam(Exam exam)
    {
        if(!exams.contains(exam))
        {
            exams.add(exam);
        }
    }
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Classname getClassname() {
        return classname;
    }

    public void setClassname(Classname classname) {
        this.classname = classname;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + Objects.hashCode(this.firstname);
        hash = 23 * hash + Objects.hashCode(this.lastname);
        hash = 23 * hash + Objects.hashCode(this.classname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (!Objects.equals(this.firstname, other.firstname)) {
            return false;
        }
        if (!Objects.equals(this.lastname, other.lastname)) {
            return false;
        }
        if (!Objects.equals(this.classname, other.classname)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Student{" + "studentId=" + studentId + ", firstname=" + firstname + ", lastname=" + lastname + ", classname=" + classname + '}';
    }


}
