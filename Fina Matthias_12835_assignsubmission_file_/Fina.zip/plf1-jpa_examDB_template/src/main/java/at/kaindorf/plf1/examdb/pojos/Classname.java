/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
/**
 *
 * @author matthiasfina
 */
@Entity
public class Classname {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
  private Long classId;
@Column(length = 10)
  private String classname;
@OneToMany(mappedBy = "student")
  private Collection<Student> students;

    public void addStudent(Student student)
    {
        if(students.contains(student))
        {
            students.add(student);
        }
    }
    public Classname() {
    }

    public Classname(String classname) {
        this.classname = classname;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Collection<Student> getStudents() {
        return students;
    }

    public void setStudents(Collection<Student> students) {
        this.students = students;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.classId);
        hash = 53 * hash + Objects.hashCode(this.classname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Classname other = (Classname) obj;
        if (!Objects.equals(this.classname, other.classname)) {
            return false;
        }
        if (!Objects.equals(this.classId, other.classId)) {
            return false;
        }
        return true;
    }

    
    @Override
    public String toString() {
        return "Classname{" + "classId=" + classId + ", classname=" + classname + '}';
    }


  
}
