/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import at.kaindorf.plf1.examdb.database.DB_Access;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bernhard Heiß
 */
public class Main 
{
    public static void main(String[] args) {
        DB_Access dba = DB_Access.getInstance();
        dba.connect();
        try {
            dba.importClassnames();
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
       // dba.getStudentsByClassnameAndSubject("2BHIF", "AM");
        dba.disconnect();
    }
}
