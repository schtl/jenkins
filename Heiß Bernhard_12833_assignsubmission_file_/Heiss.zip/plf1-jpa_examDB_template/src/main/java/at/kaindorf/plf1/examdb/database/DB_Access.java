/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Bernhard Heiß
 */
public final class DB_Access {

    private EntityManagerFactory emf;
    private EntityManager em;
    
    private static DB_Access dB_Access;
    
    public static DB_Access getInstance() 
    {
        if(dB_Access != null)
        {
            return dB_Access;
        }
        else if(dB_Access == null)
        {
            return new DB_Access();
        }
        return null;
    }

    public void connect() 
    {
        this.emf = Persistence.createEntityManagerFactory("ExamDB_PU");
        this.em = emf.createEntityManager();
    }

    public void disconnect() 
    {
        this.em.close();
        this.emf.close();
    }

    /**
     * read the classnames from csv-file and persist values
     * pathname of csv-file: \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException 
    {
        String filename = System.getProperty("user.dir") + File.separator +"src"+ File.separator +"main" + File.separator +"resources" + File.separator +"res" + File.separator +"classnames.csv";
        System.out.println(filename);
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String str ="";
        em.getTransaction().begin();
        while((str = br.readLine()) != null)
        {
            Classname classname = new Classname(str);
            em.persist(classname);
        }
        em.getTransaction().commit();
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        
        TypedQuery<Student> query = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        query.setParameter("pclassname", classname);
                query.setParameter("pshortname", subject);
        List<Student> list = query.getResultList();
        
        System.out.println(list);
        
        return list;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate startDate, int grade) 
    {
        TypedQuery<Student> query = em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod", Student.class);
        query.setParameter("pgrade", grade);
                query.setParameter("startdate", startDate);
                query.setParameter("startDate", startDate);
        List<Student> list = query.getResultList();
        
        System.out.println(list);
        return list.size();
    }

}
