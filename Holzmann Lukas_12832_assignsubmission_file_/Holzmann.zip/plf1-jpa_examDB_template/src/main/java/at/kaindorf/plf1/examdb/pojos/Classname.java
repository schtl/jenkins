/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
/**
 *
 * @author Lukas Holzmann
 */
@Entity
public class Classname {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long classId;
  private String classname;
  @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "classname")
  private Collection<Student> students;

    public Classname() {
    }

    public Classname(String classname) {
        this.classname = classname;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }
    
    public void addStudent(Student s) {
        if(!students.contains(s)) {
            students.add(s);
        }
    }
  
  
  
}
