/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Lukas Holzmann
 */
public final class DB_Access {

    // ToDo: insert singleton-code here
    private static DB_Access access;
    private EntityManagerFactory emf;
    private EntityManager em;

    public DB_Access() {
        access = this;
    }
    
    
    
    public static DB_Access getInstance() {
        // ToDo: insert code here
        return access;
    }

    public void connect() {
        // ToDo: insert code here
        emf = Persistence.createEntityManagerFactory("ExamDB_PU");
        em = emf.createEntityManager();
        em.getTransaction().begin();
        
    }

    public void disconnect() {
        // ToDo: insert code here
        em.getTransaction().commit();
        em.close();
        emf.close();
        
    }

    /**
     * read the classnames from csv-file and persist values
     * pathname of csv-file: \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        // ToDo: insert code here
        String path = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" 
                + File.separator+"resources" + File.separator+"res" + File.separator + "classnames.csv";
        FileReader fr = new FileReader(path);
        BufferedReader br = new BufferedReader(fr);
        
        String line = "";
        while((line = br.readLine()) != null) {
            String parts[] = line.split(";");
            Classname classname = new Classname(parts[0]);
            em.persist(classname);
        }
            br.close();
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        List<Student> students = new ArrayList<>();
        TypedQuery tq = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        tq.setParameter("classname", classname);
        tq.setParameter("subject", subject);
        students = tq.getResultList();
        return students;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        Long count = 0L;
        TypedQuery tq = em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod", Student.class);
        tq.setParameter("startDate", startDate);
        tq.setParameter("endDate", endDate);
        //tq.setParameter("grade", grade);
        if(!tq.getResultList().isEmpty()) {
            count = Long.parseLong(tq.getResultList().get(0).toString());
        }
        
        return count;
    }
    
    public static void main(String[] args) {
        DB_Access access = new DB_Access();
        access.connect();
        try {
            access.importClassnames();
        } catch (IOException ex) {
           ex.printStackTrace();
        }
        access.getStudentsByClassnameAndSubject("1AHME", "D");
        access.countStudentsFromGradeWithExamInTimePeriod(LocalDate.now(),LocalDate.now(),1);
        access.disconnect();
    }

}
