/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author Lukas Ulbing
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "Student.getStudentsByClassnameAndSubject", query = "SELECT s FROM Student s WHERE s.classname.classname LIKE :classname AND (SELECT e FROM Exam e WHERE e.subject.shortname LIKE :shortname) = "),
    @NamedQuery(name = "Student.countStudentsFromGradeWithExamInTimePeriod", query = "SELECT count(s) FROM Student s WHERE s.classname.classname LIKE :year+'*'")
})
public class Student implements Comparable<Student>{

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(nullable = false)
    private Long studentId;
    @Column(length = 80)
    private String firstname;
    @Column(length = 80)
    private String lastname;

    @OneToMany(mappedBy = "student")
    @JoinColumn(nullable = false)
    private Collection<Exam> exams;

    @ManyToOne
    @JoinColumn(name = "classname", nullable = false)
    private Classname classname;

    public Student() {
    }

    public Student(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }

    public Classname getClassname() {
        return classname;
    }

    public void setClassname(Classname classname) {
        this.classname = classname;
    }

    @Override
    public int compareTo(Student stu) {
        return this.getLastname().compareTo(stu.getLastname());
    }

}
