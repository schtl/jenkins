/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.database;

import at.kaindorf.plf1.examdb.pojos.Classname;
import at.kaindorf.plf1.examdb.pojos.Student;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Lukas Ulbing
 */
public final class DB_Access {

    private EntityManagerFactory emf;
    private EntityManager em = null;

    // ToDo: insert singleton-code here
    private static DB_Access theInstance = null;

    public static DB_Access getInstance() {
        // ToDo: insert code here
        if (theInstance == null) {
            theInstance = new DB_Access();
        }
        return theInstance;
    }

    public void connect() {
        // ToDo: insert code here
        emf = Persistence.createEntityManagerFactory("ExamDB_PU");
        em = emf.createEntityManager();
    }

    public void disconnect() {
        // ToDo: insert code here
        em.close();
        emf.close();
    }

    /**
     * read the classnames from csv-file and persist values pathname of
     * csv-file:
     * \home\student\NetBeansProjects\plf1-jpa_examDB_template\src\main\resources\res\classnames.csv
     * Classname-objects in database
     *
     * @throws IOException
     */
    public void importClassnames() throws IOException {
        // ToDo: insert code here
        String path = System.getProperty("user.dir") + File.separator
                + "src" + File.separator
                + "main" + File.separator
                + "resources" + File.separator
                + "res" + File.separator
                + "classnames.csv";
        FileReader fr = new FileReader(path);
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            Classname classname = new Classname(line);
            em.persist(classname);
        }
        em.getTransaction().begin();
        em.getTransaction().commit();
    }

    /**
     * use named query "Student.getStudentsByClassnameAndSubject" to get a list
     * containing all students of a specific class that have an exam in a
     * specific subject identified by the shortname. The students are sorted by
     * lastname.
     *
     * @param classname for selection
     * @param subject shortname of subject for selection
     * @return list of students
     */
    public List<Student> getStudentsByClassnameAndSubject(String classname, String subject) {
        // ToDo: insert code here
        TypedQuery<Student> studentQuery = em.createNamedQuery("Student.getStudentsByClassnameAndSubject", Student.class);
        studentQuery.setParameter("classname", classname);
        studentQuery.setParameter("shortname", subject);
        List<Student> studentList = studentQuery.getResultList();
        return studentList;
    }

    /**
     * use named query Student.countStudentsFromGradeWithExamInTimePeriod to get
     * the number of all students of a specific grade (1-5) within a specific
     * time-period
     *
     * @return number of students
     */
    public Long countStudentsFromGradeWithExamInTimePeriod(LocalDate startDate, LocalDate endDate, int grade) {
        // ToDo: insert code here
        TypedQuery<Number> query = em.createNamedQuery("Student.countStudentsFromGradeWithExamInTimePeriod", Number.class);
        query.setParameter("startdate", startDate);
        query.setParameter("enddate", endDate);
        query.setParameter("grade", grade);
        return Long.parseLong(query.getSingleResult() + "");
    }

    public static void main(String[] args) {
        DB_Access dbaccess = DB_Access.getInstance();
        dbaccess.connect();
        try {
            dbaccess.importClassnames();
        } catch (IOException ex) {
            System.out.println("Exception while importing!");
        }
        dbaccess.disconnect();
    }

}
