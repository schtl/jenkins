/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.kaindorf.plf1.examdb.pojos;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author Kevin Trummer
 */
@Entity
public class Subject implements Serializable
{
  @Id
  private Long subjectId;
  private String longname;
  private String shortname;
  private boolean written;
  @OneToMany(mappedBy = "subject", cascade = CascadeType.ALL)
  private Collection<Exam> exams;

    public Subject() {
    }

    public Subject(String longname, String shortname, boolean written, Collection<Exam> exams) {
        this.longname = longname;
        this.shortname = shortname;
        this.written = written;
        this.exams = exams;
    }

    public Long getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Long subjectId) {
        this.subjectId = subjectId;
    }

    public String getLongname() {
        return longname;
    }

    public void setLongname(String longname) {
        this.longname = longname;
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    public boolean isWritten() {
        return written;
    }

    public void setWritten(boolean written) {
        this.written = written;
    }

    public Collection<Exam> getExams() {
        return exams;
    }

    public void setExams(Collection<Exam> exams) {
        this.exams = exams;
    }
  
  
}
